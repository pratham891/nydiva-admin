import React from 'react';
import { Navbar, Nav } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const Header = () => (
  <Navbar bg="light" expand="lg" className="border-bottom">
    <Navbar.Brand href="/" className="fw-bold text-dark">Admin Dashboard</Navbar.Brand>
    <Navbar.Toggle aria-controls="basic-navbar-nav" />
    <Navbar.Collapse id="basic-navbar-nav">
      <Nav className="me-auto">
        <Nav.Link as={Link} to="/" className="text-dark fw-semibold">Home</Nav.Link>
        <Nav.Link as={Link} to="/manage-products" className="text-dark fw-semibold">Manage Products</Nav.Link>
      </Nav>
    </Navbar.Collapse>
  </Navbar>
);

export default Header;
