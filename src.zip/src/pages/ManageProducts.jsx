import React, { useState } from 'react';
import productsData from '../data';
import { v4 as uuidv4 } from 'uuid';

const ManageProducts = () => {
  const [products, setProducts] = useState(productsData);
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    description: '',
    image: null,
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFormData({ ...formData, image: file });
  };

  const handleAddProduct = () => {
    if (!formData.name || !formData.price || !formData.description || !formData.image) {
      alert('All fields are required.');
      return;
    }

    const newProduct = {
      id: uuidv4(),
      name: formData.name,
      price: parseFloat(formData.price),
      description: formData.description,
      image: URL.createObjectURL(formData.image), // Temporarily set URL for preview
    };

    // Simulate file storage
    const fileReader = new FileReader();
    fileReader.onload = () => {
      const imageData = fileReader.result;
      localStorage.setItem(`product-${newProduct.id}`, imageData); // Simulate storing the image
    };
    fileReader.readAsDataURL(formData.image);

    setProducts([...products, newProduct]);
    setFormData({ name: '', price: '', description: '', image: null });
  };

  const handleDeleteProduct = (id) => {
    const updatedProducts = products.filter((product) => product.id !== id);
    setProducts(updatedProducts);
  };

  return (
    <div>
      <h3>Manage Products</h3>

      {/* Add Product Form */}
      <form>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Product Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="price" className="form-label">Product Price</label>
          <input
            type="number"
            id="price"
            name="price"
            value={formData.price}
            onChange={handleInputChange}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="description" className="form-label">Product Description</label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleInputChange}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="image" className="form-label">Product Image</label>
          <input
            type="file"
            id="image"
            onChange={handleFileChange}
            className="form-control"
            accept="image/*"
          />
        </div>
        <button type="button" onClick={handleAddProduct} className="btn btn-primary">
          Add Product
        </button>
      </form>

      {/* Product List */}
      <div className="mt-4">
        <h4>Product List</h4>
        {products.length === 0 ? (
          <p>No products available.</p>
        ) : (
          <ul className="list-group">
            {products.map((product) => (
              <li key={product.id} className="list-group-item d-flex align-items-center">
                <img
                  src={product.image}
                  alt={product.name}
                  className="me-3"
                  style={{ width: '50px', height: '50px', objectFit: 'cover' }}
                />
                <div>
                  <strong>{product.name}</strong>
                  <p className="mb-0">Price: ${product.price}</p>
                  <p className="mb-0">{product.description}</p>
                </div>
                <button
                  className="btn btn-danger ms-auto"
                  onClick={() => handleDeleteProduct(product.id)}
                >
                  Delete
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default ManageProducts;
